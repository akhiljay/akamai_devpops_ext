chrome.devtools.panels.create(
	"Devpops", 
	"img/16_devpops_icon.png", 
	"index.html",
	function() {}
);